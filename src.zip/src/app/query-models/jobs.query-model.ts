export interface JobsQueryModel {
  readonly title: string;
  readonly jobTags: string[];
}
