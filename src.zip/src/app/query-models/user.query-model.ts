export interface UserQueryModel {
  readonly email: string;
  readonly role: string;
  
}
