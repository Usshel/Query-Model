export interface UserDepartmentAndRoleQueryModel {
  readonly email: string;
  readonly role: string;
  readonly department: string;
}
