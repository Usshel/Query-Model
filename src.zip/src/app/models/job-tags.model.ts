export interface JobTagsModel {
  readonly name: string;
  readonly id: string;
}
