export interface JobPostsModel {
  readonly title: string;
  readonly description: string;
  readonly jobTagIds: number[];
  readonly id: string;
}
