export interface RoleModel {
  readonly id: number;
  readonly role: string;
}
