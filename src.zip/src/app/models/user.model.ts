export interface UserModel {
  readonly email: string;
  readonly roleId: number;
  readonly departmentId: number;
  readonly id: string;
}
